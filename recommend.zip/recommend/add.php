<html>
<head>
<title>Add Recommendation</title>
<style>
.formLabel{
	display:inline-block;
	margin-bottom:20px;
	border:1px solid grey;
	padding:10px;
	background-color:white;
}
#center{
	
	display:flex;
	justify-content:center;
	
}
body{
	background-color:#e6ebf2;
}
</style>

</head>

<body>

<div id="center"> 
<form action="upload.php" method="POST" enctype="multipart/form-data">
 
<h3>Once you click upload, this will go live to the world.<br> Make it ROCK!</h3>
 
 <label class="formLabel"><input type="text" name="fullname" placeholder="Your Full Name" maxlength="25"><br> *required <br>Please type your name</label><br>
<label class="formLabel"><input type="text" name="job" placeholder="Who are you?" maxlength="25"><br> *required <br>Please type in your relationship to me. Example, Martin's Boss</label><br>
 <label class="formLabel"><textarea name="recommend" rows="4" cols="50" placeholder="Say something nice about me" maxlength="200"></textarea><br>  *required <br>Say something nice about me</label><br>


<label class="formLabel">Pick image 200kb limit <br>*not required but would be nice <br><br><input type="file" name="file">
<button type="submit" name="submit">UPLOAD</button></label>
</form>

</div>

 

</body>
</html>
