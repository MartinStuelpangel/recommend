<?php




function clean($value){
	$value=trim($value);
	$value=stripslashes($value);
	$value=strip_tags($value);


	return $value;
}


function someoneAdded(){
$msg = "A recommendation was added.";
mail("martin@mstuelpnagel.com","Recommendation added",$msg);	

}



?>