<!--include this file where you want the html to go-->
<style>

.formPic{
	 width:100px;
	 height:100px;
	border-radius: 50%;
	padding:4px;
	border:1px solid black;
}

.formFlex{
	 display:flex;
	 flex-wrap: wrap;
	 justify-content: space-evenly;
	 width:70%;
	  
}

.formItems{
	margin-top:20px; 
	width:200px;
	line-height:20px;
	padding-left:8px; 
	overflow-wrap: break-word;
	 
}
.formChuncks{
	 display:flex;
	margin-bottom:5px;
	margin-left:10px;
}

</style>

<div class="formFlex">
<?php

require 'connection.php';

	$sqlSelect="select * from people";
	$resultsSelect=mysqli_query($conn,$sqlSelect);
	
	$resultsCheck=mysqli_num_rows($resultsSelect);
		if($resultsCheck>0){
			while($row=mysqli_fetch_assoc($resultsSelect)){	
				echo "<div class='formChuncks'>";
				echo "<img src='".$row['avatar']."' class='formPic' />"."<br>";
				echo "<div class='formItems'>";
				echo $row['full_name']."<br>";
				echo $row['job']."<br>";
				echo $row['recommend']."<br>";
				echo "</div>";
				echo "</div>"; 
				
					 
		
			}
	}
mysqli_close($conn);

?>
</div>