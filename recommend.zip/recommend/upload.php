<?php 

require 'functions.php';
require 'connection.php';


//this gets the refereing file name
$fileName = substr($_SERVER["HTTP_REFERER"],strrpos($_SERVER["HTTP_REFERER"],"/")+1);  
 
//this is in case they go directly to this file so no blank entry is made.
if($fileName!=="add.php"){
	header("Location: add.php");
 exit();
}



if(isset($_POST['submit'])){

	$fullName=clean($_POST['fullname']);
	$job=clean($_POST['job']);
	$recommend=clean($_POST['recommend']);

if($fullName===""||$job===""||$recommend===""){
	
	echo "<div style='margin-top:200px; margin-left:auto; margin-right:auto; width:300px; background-color:#e6ebf2; border:1px solid black; padding:10px; text-align: center;'>"."<h4>Please fill out all the text boxes</h4>"."<a href='add.php' style='font-size:20px;'>Please Go Back</a> </div>";
					exit( );
	
}
 


	$file=$_FILES['file'];
	
	$fileName=$_FILES['file']['name'];
	$fileTmpName=$_FILES['file']['tmp_name'];
	$fileSize=$_FILES['file']['size'];
	$fileError=$_FILES['file']['error'];
	$fileType=$_FILES['file']['type'];
	
//this is so they can skip picking an image and the default image is used.
	$fileExt=explode('.',$fileName);
	$fileActualExt=strtolower(end($fileExt));
	
		if($fileActualExt===""){
			$fileActualExt='ok';
		}
	
	
if (empty($fileName))
	{$fileDestination="noone.png";}else{
	$allowed=array('jpg','jpeg','png','ok'); 
		if(in_array($fileActualExt, $allowed)){
			if($fileError===0){
				if($fileSize<200000){
					$fileNameNew=uniqid('',true).".".$fileActualExt;
					$fileDestination="uploads/".$fileNameNew;
					move_uploaded_file($fileTmpName,$fileDestination);
					 
				}else{
					echo "<div style='margin-top:200px; margin-left:auto; margin-right:auto; width:300px; background-color:#e6ebf2; border:1px solid black; padding:10px; text-align: center;'>"."<h4>Your image upload size is too large 200kb or less please</h4>"."<a href='add.php' style='font-size:20px;'>Please go back and pick a newfile.</a></div>";
					exit( );
				}
			}else{
				echo "<div style='margin-top:200px; margin-left:auto; margin-right:auto; width:300px; background-color:#e6ebf2; border:1px solid black; padding:10px; text-align: center;'>"."<h4>There was an error uploading</h4>"."<a href='add.php' style='font-size:20px;'>Go Back</a></div>";
				 
			}
		}else{
			echo "<div style='margin-top:200px; margin-left:auto; margin-right:auto; width:300px; background-color:#e6ebf2; border:1px solid black; padding:10px; text-align: center;'>"."<h4>Only jpg, jpeg, and png files allowed</h4>"."<a href='add.php' style='font-size:20px;'>Please go back and pick a newfile.</a></div>";
			exit( );
		}


	}
}
	
 

 
	
 
	
$sql="insert into people(full_name,job,recommend,avatar) values ('$fullName','$job','$recommend','$fileDestination');";

$result=mysqli_query($conn, $sql);


mysqli_close($conn);



someoneAdded(); 

header("Location:index.php");


 
exit();
?>