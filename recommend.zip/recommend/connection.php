<?php

  // for server on my site
  $dbServername="localhost";
 $dbUsername="martinsb_myBob";
$dbPassword="b0b12345B0b!";
$dbName="martinsb_myreferences";

/*
$dbServername="localhost";
$dbUsername="Mytest012";
$dbPassword="test12345";
$dbName="myreferences";
*/
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

 
  /* for server on my site
  $dbServername="localhost";
 $dbUsername="martinsb_myBob";
$dbPassword="b0b12345B0b!";
$dbName="martinsb_myreferences";
*/

?>